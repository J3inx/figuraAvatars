local license = [[
Copyright (c) 2025 Sparkie_Kat

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software within restriction, including without limitation the rights
to use, copy, modify, merge for personal use or publish modified copies of the Software without monetization.
No permission is granted to distribute, sublicense, and/or sell copies of the Software.

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.
]]
