# Figura PhysBone API
An easy to use, and highly customisable physics system.

For how to use, go to [The physBone Wiki](https://github.com/ChloeSpacedOut/figura-physbone-api/wiki).

If you find any issues I missed or have any features you think would be useful, please let me know and I'll see what I can do! You're also more than welcome to contribute to the project yourself if you'd like
