Feature list:
- Custom models for the trident (wizard staff) and tools (wand)
- Custom staff walking animation
- Staff and wand attacking animations
- Generate static to power your magical weapons (static indicator on top of the screen)
  - Press H to scratch your beard
  - Ponder the orb in the world or in your hand
  - Lightning striking near you will generate static
  - Walking on wool with your staff will generate static
- Use static by attacking with the staff or wand

Includes GSAnimBlend by Grandpa Scout