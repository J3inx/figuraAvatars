# ClothesLib
Library to create clothes, outfits in your avatar!

See [main.lua](main.lua) for example usage

you can also download this repository to try out the example avatar