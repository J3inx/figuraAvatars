super simple tail and ears physics in figura
`tail.lua` is required for tail physics
`ears.lua` required for ears physics
`example.bbmodel` not required but used as example
